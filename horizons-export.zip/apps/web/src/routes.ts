import { type RouteConfig, index, route } from '@react-router/dev/routes';

export default [
	index('routes/home.tsx'),
	route('courses/:slug', 'routes/course.tsx'),
	route('contact', 'routes/contact.tsx'),
	route('privacy', 'routes/privacy.tsx'),
	route('enquire', 'routes/enquire.tsx'),
	route('llms.txt', 'routes/llms.txt.ts'),
	route('sitemap.xml', 'routes/sitemap.xml.ts'),
	route('robots.txt', 'routes/robots.txt.ts'),
	route('api/health', 'routes/api.health.ts'),
	route('api/*', 'routes/api.$.ts'),
] satisfies RouteConfig;
