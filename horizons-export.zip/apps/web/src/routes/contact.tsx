import type { Route } from './+types/contact';
import { seo } from '@/lib/seo';
import { banners } from '@/data/home-content';
import { ContactContent } from '@/components/contact-content';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Contact NxoraIT — email & phone',
		description: 'Contact NxoraIT for course enquiries, batch schedules and fees. Email info@nxorait.com or call +91-9985399924.',
		image: banners[0].src,
		jsonLd: [
			{
				'@context': 'https://schema.org',
				'@type': 'EducationalOrganization',
				name: 'NxoraIT',
				email: 'info@nxorait.com',
				telephone: '+91-9985399924',
				description: 'An online IT training institute offering practical, instructor-led technology learning.',
			},
		],
	});
}

export default function ContactPage() {
	return <ContactContent />;
}
