import type { Route } from './+types/course';
import { courses, learnerImage } from '@/data/courses';
import { seo } from '@/lib/seo';
import { CourseDetail } from '@/components/course-detail';
import { Enquiry } from '@/components/enquiry';
export function loader({params}:Route.LoaderArgs){const course=courses.find(item=>item.slug===params.slug);if(!course)throw new Response('Course not found',{status:404});return {course};}
export function meta({matches,location,loaderData}:Route.MetaArgs){const course=loaderData?.course;return seo({matches,location},{title:course?`${course.title} — NxoraIT`:'Course not found — NxoraIT',description:course?`Explore ${course.title.toLowerCase()} with NxoraIT. Build practical skills through guided online sessions and projects. Ask about upcoming batches and fees.`:'This learning pathway could not be found. Explore the online IT training courses available at NxoraIT.',image:learnerImage,noindex:!course,jsonLd:course?{'@context':'https://schema.org','@type':'Course',name:course.title,description:course.description,provider:{'@type':'EducationalOrganization',name:'NxoraIT'}}:undefined});}
export default function CoursePage({loaderData}:Route.ComponentProps){return <main><CourseDetail course={loaderData.course}/><Enquiry key={loaderData.course.slug} selectedCourse={loaderData.course.title}/></main>;}
