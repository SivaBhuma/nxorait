import type { Route } from './+types/privacy';
import { seo } from '@/lib/seo';
import { learnerImage } from '@/data/courses';
import { PrivacyContent } from '@/components/privacy-content';
export function meta({matches,location}:Route.MetaArgs){return seo({matches,location},{title:'Privacy policy — NxoraIT',description:'Learn how NxoraIT handles your course enquiry, protects your personal information and gives you control over cookies and contact preferences.',image:learnerImage});}
export default function PrivacyPage(){return <PrivacyContent/>;}
