import type { Route } from './+types/home';
import { seo } from '@/lib/seo';
import { faqs } from '@/data/courses';
import { banners } from '@/data/home-content';
import { BannerSlider } from '@/components/home/banner-slider';
import { Welcome } from '@/components/home/welcome';
import { Services } from '@/components/home/services';
import { FeaturedCourses } from '@/components/home/featured-courses';
import { LatestBlog } from '@/components/home/latest-blog';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'NxoraIT — Learn Today, Build Tomorrow, Lead the Future',
		description: 'Explore practical IT training courses in DevOps, cloud computing, data engineering, AI, Docker, Kubernetes, Python, and middleware technologies.',
		image: banners[0].src,
		jsonLd: [
			{ '@context': 'https://schema.org', '@type': 'WebSite', name: 'NxoraIT', description: 'Practical online IT training for your next chapter.' },
			{ '@context': 'https://schema.org', '@type': 'EducationalOrganization', name: 'NxoraIT', description: 'An online IT training institute offering practical, instructor-led technology learning.' },
			{ '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: faqs.map(item => ({ '@type': 'Question', name: item.question, acceptedAnswer: { '@type': 'Answer', text: item.answer } })) },
		],
	});
}

export default function HomePage() {
	return (
		<main>
			<BannerSlider />
			<Welcome />
			<Services />
			<FeaturedCourses />
			<LatestBlog />
		</main>
	);
}
