import type { Route } from './+types/enquire';
import { seo } from '@/lib/seo';
import { banners } from '@/data/home-content';
import { Enquiry } from '@/components/enquiry';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'New batches — NxoraIT',
		description: 'Ask NxoraIT about upcoming batches, fees and schedules for DevOps, cloud, data, AI, Python and full-stack training.',
		image: banners[0].src,
	});
}

export default function EnquirePage() {
	return (
		<main className="nit-enquire-page">
			<Enquiry />
		</main>
	);
}
