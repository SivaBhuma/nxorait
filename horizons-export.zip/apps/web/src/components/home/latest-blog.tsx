import { Link } from 'react-router';
import { posts } from '@/data/home-content';
import { useCarousel } from '@/hooks/use-carousel';

export function LatestBlog() {
	const carousel = useCarousel({ count: posts.length, autoplayMs: 4500 });
	const visible = [0, 1, 2].map(offset => posts[(carousel.index + offset) % posts.length]);
	return (
		<section className="nit-blog" id="blog">
			<div className="nit-blog-intro">
				<h2>Latest Blog</h2>
				<p>NxoraIT is an online IT training institute providing software training, project guidance and practical technology workshops.</p>
				<Link to="/#courses" className="nit-read">Read More</Link>
			</div>
			<div className="nit-blog-carousel" {...carousel.regionProps} aria-label="Latest articles">
				{visible.map(post => (
					<article key={post.title}>
						<Link to={post.href}>
							<img src={post.image} srcSet={post.srcSet} sizes="(min-width: 900px) 240px, 80vw" alt="" width={480} height={270} />
							<h3>{post.title}</h3>
						</Link>
						<span>0 Comment</span>
						<p>{post.excerpt}</p>
					</article>
				))}
			</div>
			<div className="nit-blog-dots">
				{posts.map((post, index) => (
					<button key={post.title} type="button" className={index === carousel.index ? 'is-active' : ''} aria-label={`Show articles starting at ${post.title}`} onClick={() => carousel.goTo(index)} />
				))}
			</div>
		</section>
	);
}
