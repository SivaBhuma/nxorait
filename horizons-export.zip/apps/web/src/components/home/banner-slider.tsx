import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Link } from 'react-router';
import { banners } from '@/data/home-content';
import { useCarousel } from '@/hooks/use-carousel';

export function BannerSlider() {
	const carousel = useCarousel({ count: banners.length, autoplayMs: 5000 });
	return (
		<section className="nit-slider" {...carousel.regionProps} aria-label="Featured training batches">
			{banners.map((banner, index) => (
				<Link key={banner.src} to={banner.href} className={index === carousel.index ? 'is-active' : ''} hidden={index !== carousel.index} aria-hidden={index !== carousel.index}>
					<img src={banner.src} {...(banner.srcSet ? { srcSet: banner.srcSet, sizes: '(min-width: 1200px) 1140px, 100vw' } : {})} alt={banner.alt} width={1472} height={630} fetchPriority={index === 0 ? 'high' : 'low'} />
				</Link>
			))}
			<button type="button" className="nit-arrow nit-prev" onClick={carousel.prev} aria-label="Previous banner"><ChevronLeft size={28} /></button>
			<button type="button" className="nit-arrow nit-next" onClick={carousel.next} aria-label="Next banner"><ChevronRight size={28} /></button>
			<div className="nit-dots">
				{banners.map((banner, index) => (
					<button key={banner.alt} type="button" className={index === carousel.index ? 'is-active' : ''} aria-label={`Show banner ${index + 1}`} onClick={() => carousel.goTo(index)} />
				))}
			</div>
		</section>
	);
}
