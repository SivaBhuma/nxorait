import { Plus } from 'lucide-react';
import { faqs } from '@/data/courses';
export function Faq(){return <section className="faq-section section-rail" id="faq"><div><span className="eyebrow">04 / GOOD QUESTIONS</span><h2>A little clarity.<br/><em>A confident start.</em></h2><p>Still have something on your mind?<br/><a href="#enquire" className="text-link">Ask the NxoraIT team ↗</a></p></div><div className="faq-list">{faqs.map(item=><details key={item.question}><summary>{item.question}<Plus size={20}/></summary><p>{item.answer}</p></details>)}</div></section>;}
