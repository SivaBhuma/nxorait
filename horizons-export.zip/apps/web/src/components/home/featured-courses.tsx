import { Link } from 'react-router';
import { featured } from '@/data/home-content';

export function FeaturedCourses() {
	const loop = [...featured, ...featured];
	return (
		<section className="nit-featured" id="courses" aria-label="Featured software courses">
			<h2>Featured Software Courses</h2>
			<div className="nit-marquee">
				<div className="nit-track">
					{loop.map((course, index) => (
						<Link key={`${course.label}-${index}`} to={course.href} style={{ background: course.tone, color: course.ink ?? '#fff' }} aria-hidden={index >= featured.length}>
							<strong>{course.label}</strong>
						</Link>
					))}
				</div>
			</div>
		</section>
	);
}
