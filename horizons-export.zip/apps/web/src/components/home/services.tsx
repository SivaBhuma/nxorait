import { LayoutGrid, Triangle, Copy, Presentation, Building2 } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

const services: { title: string; text: string; icon: LucideIcon }[] = [
	{ title: 'Software Training', icon: LayoutGrid, text: 'NxoraIT is an online IT training institute offering practical courses in DevOps, cloud, data engineering, AI, Docker, Kubernetes, Python and middleware.' },
	{ title: 'Project Training', icon: Triangle, text: 'Project training you can join from anywhere with an internet connection. Instructors guide classroom-style sessions and real-time online labs.' },
	{ title: 'Weekend Workshops', icon: Copy, text: 'Your team trained around your schedule. Learn content tailored to your organisation. You set the date and time and we deliver it.' },
	{ title: 'IT Consulting', icon: Presentation, text: 'NxoraIT helps teams adopt practical technology skills, from Python and cloud platforms to data analytics and secure delivery.' },
	{ title: 'Classroom Training', icon: LayoutGrid, text: 'Live instructor-led sessions with structured course material, demonstrations and time to ask questions as you build.' },
	{ title: 'Online Training', icon: Triangle, text: 'We offer most of the course online so you can learn from home and still get guided practice for real IT work.' },
	{ title: 'Corporate Training', icon: Building2, text: 'Experienced faculty train professionals who want to improve their technology skills for day to day delivery.' },
];

export function Services() {
	return (
		<section className="nit-services" id="services">
			<h2>Our Training Services</h2>
			<div className="nit-service-grid">
				{services.map(service => {
					const Icon = service.icon;
					return (
						<article key={service.title}>
							<span><Icon size={34} strokeWidth={1.6} /></span>
							<h3>{service.title}</h3>
							<p>{service.text}</p>
						</article>
					);
				})}
			</div>
		</section>
	);
}
