import { Link } from 'react-router';

export function Welcome() {
	return (
		<section className="nit-welcome" id="welcome">
			<div className="nit-tagline">
				<span>Learn Today,</span>
				<span>Build Tomorrow,</span>
				<span>Lead The Future.</span>
			</div>
			<h1>Welcome To NxoraIT! How can we help you...</h1>
			<p>
				It is a long established fact that a student will be distracted by the number of <Link to="/#courses">software training institutes</Link> when looking for the best classroom and <Link to="/#services">online training</Link> in practical IT skills.
			</p>
		</section>
	);
}
