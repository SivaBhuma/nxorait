import { MessageCircle, X } from 'lucide-react';
import { useDisclosure } from '@/hooks/use-disclosure';
import { Link } from 'react-router';

export function ChatWidget() {
	const chat = useDisclosure();
	return (
		<div className="nit-chat">
			{chat.isOpen ? (
				<div className="nit-chat-panel" {...chat.panelProps}>
					<strong>We&apos;re Online!</strong>
					<p>How may I assist you?</p>
					<Link to="/enquire" onClick={chat.close}>Send an enquiry</Link>
					<button type="button" onClick={chat.close} aria-label="Close chat"><X size={14} /></button>
				</div>
			) : (
				<div className="nit-chat-bubble">
					<strong>We&apos;re Online!</strong>
					<p>How may I assist you?</p>
				</div>
			)}
			<button type="button" className="nit-chat-btn" {...chat.triggerProps} aria-label={chat.isOpen ? 'Close assistance' : 'Open assistance'}>
				<MessageCircle size={26} />
			</button>
		</div>
	);
}
