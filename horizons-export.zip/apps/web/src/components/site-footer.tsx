import { Link } from 'react-router';
import { Facebook, Instagram, Linkedin, Youtube, X } from 'lucide-react';
import { openCookiePreferences } from '@/lib/cookie-consent';

export function SiteFooter() {
	return (
		<footer className="nit-footer">
			<div className="nit-footer-grid">
				<div>
					<h2>About NxoraIT</h2>
					<p>NxoraIT (pronounced Nxora IT) is an online IT training institute providing software training, project guidance and technology workshops. Learn today, build tomorrow, and lead the future with practical courses in DevOps, cloud, data, AI, Docker, Kubernetes and Python.</p>
				</div>
				<div>
					<h2>Popular pathways</h2>
					<ul>
						<li><Link to="/courses/python-programming">Python interview practice</Link></li>
						<li><Link to="/courses/full-stack-development">Full-stack interview practice</Link></li>
						<li><Link to="/courses/data-science-ai">Data science questions</Link></li>
						<li><Link to="/courses/cloud-devops">DevOps questions</Link></li>
					</ul>
				</div>
				<div>
					<h2>Online training desk</h2>
					<p><strong>For online training:</strong></p>
					<p>Ask about batches, fees and schedules through the enquiry desk. A team member confirms the next start date before you enrol.</p>
					<p><Link to="/enquire">Send an enquiry</Link></p>
					<p><Link to="/contact">Contact details</Link></p>
					<p><Link to="/privacy">Privacy policy</Link></p>
				</div>
				<div>
					<h2>Follow us on social media</h2>
					<div className="nit-footer-social">
						<a href="https://facebook.com" aria-label="Facebook" target="_blank" rel="noreferrer"><Facebook size={14} /></a>
						<a href="https://instagram.com" aria-label="Instagram" target="_blank" rel="noreferrer"><Instagram size={14} /></a>
						<a href="https://linkedin.com" aria-label="LinkedIn" target="_blank" rel="noreferrer"><Linkedin size={14} /></a>
						<a href="https://x.com" aria-label="X" target="_blank" rel="noreferrer"><X size={14} /></a>
						<a href="https://youtube.com" aria-label="YouTube" target="_blank" rel="noreferrer"><Youtube size={14} /></a>
					</div>
					<h2 className="nit-subhead">Join our updates</h2>
					<ul>
						<li><Link to="/enquire">NxoraIT batch updates</Link></li>
						<li>Python | Cloud | DevOps | Data | AI</li>
					</ul>
					<button type="button" onClick={openCookiePreferences}>Cookie settings</button>
				</div>
			</div>
			<p className="nit-copy">© 2026 NxoraIT | Software Training - Online Training - Live Project Training - Weekend Training</p>
		</footer>
	);
}
