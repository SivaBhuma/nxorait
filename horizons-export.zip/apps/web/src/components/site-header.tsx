import { Link, NavLink } from 'react-router';
import { Facebook, Instagram, Linkedin, Send, Youtube, Menu, X } from 'lucide-react';
import { useDisclosure } from '@/hooks/use-disclosure';

const links = [
	['Home', '/'],
	['All Courses', '/#courses'],
	['Services', '/#services'],
	['Software Training', '/#services'],
	['Projects', '/#services'],
	['Internships', '/enquire'],
	['Careers', '/enquire'],
	['About', '/#welcome'],
	['Contact', '/contact'],
	['New Batches', '/enquire'],
	['Blog', '/#blog'],
] as const;

export function SiteHeader() {
	const menu = useDisclosure();
	return (
		<header className="nit-header">
			<div className="nit-top">
				<Link to="/" className="nit-logo" aria-label="NxoraIT home">
					<img src="https://horizons-cdn.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/5bb9dae9870183663e5e17a16a40a7fb.png" alt="NxoraIT — Empowering Future Tech Skills" width="92" height="92" />
					<span>Learn Today, Build Tomorrow, Lead the Future.</span>
				</Link>
				<div className="nit-social">
					<p>FOLLOW US SOCIAL MEDIA :</p>
					<div>
						<a href="https://facebook.com" aria-label="Facebook" target="_blank" rel="noreferrer"><Facebook size={14} /></a>
						<a href="https://instagram.com" aria-label="Instagram" target="_blank" rel="noreferrer"><Instagram size={14} /></a>
						<a href="https://linkedin.com" aria-label="LinkedIn" target="_blank" rel="noreferrer"><Linkedin size={14} /></a>
						<a href="https://t.me" aria-label="Telegram" target="_blank" rel="noreferrer"><Send size={14} /></a>
						<a href="https://x.com" aria-label="X" target="_blank" rel="noreferrer"><X size={14} /></a>
						<a href="https://youtube.com" aria-label="YouTube" target="_blank" rel="noreferrer"><Youtube size={14} /></a>
					</div>
				</div>
			</div>
			<nav className="nit-nav" aria-label="Main navigation">
				{links.map(([label, href]) => (
					<NavLink key={label} to={href} end={href === '/'}>{label}</NavLink>
				))}
				<button type="button" className="nit-menu" {...menu.triggerProps} aria-label={menu.isOpen ? 'Close menu' : 'Open menu'}>{menu.isOpen ? <X /> : <Menu />}</button>
			</nav>
			{menu.isOpen && (
				<nav className="nit-mobile" {...menu.panelProps} aria-label="Mobile navigation">
					{links.map(([label, href]) => (
						<Link key={label} to={href} onClick={menu.close}>{label}</Link>
					))}
				</nav>
			)}
		</header>
	);
}
