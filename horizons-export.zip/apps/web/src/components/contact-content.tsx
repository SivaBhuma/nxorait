import { Link } from 'react-router';
import { Mail, Phone, MessageCircle, ArrowUpRight, Clock, Send } from 'lucide-react';
import { mailtoHref, telHref, whatsappUrl } from '@/lib/contact-links';

const EMAIL = 'info@nxorait.com';
const PHONE = '+91-9985399924';

export function ContactContent() {
	return (
		<section className="contact-section">
			<div className="section-rail contact-inner">
				<div className="contact-copy">
					<span className="eyebrow">CONTACT</span>
					<h2>Let’s talk about<br />your <em>next step</em>.</h2>
					<p>Have a question about a course, batch schedule, fees or career guidance? Reach out — the NxoraIT team is happy to help you find the right pathway.</p>
					<ul className="contact-list">
						<li>
							<span className="contact-icon"><Mail size={18} /></span>
							<span className="contact-detail">
								<small>Email</small>
								<a href={mailtoHref({ email: EMAIL, subject: 'Course enquiry — NxoraIT' })}>{EMAIL}</a>
							</span>
						</li>
						<li>
							<span className="contact-icon"><Phone size={18} /></span>
							<span className="contact-detail">
								<small>Phone</small>
								<a href={telHref(PHONE)}>{PHONE}</a>
							</span>
						</li>
						<li>
							<span className="contact-icon"><MessageCircle size={18} /></span>
							<span className="contact-detail">
								<small>WhatsApp</small>
								<a href={whatsappUrl({ phone: PHONE, text: 'Hi NxoraIT, I’d like to know more about your courses.' })} target="_blank" rel="noreferrer">Chat with us</a>
							</span>
						</li>
						<li>
							<span className="contact-icon"><Clock size={18} /></span>
							<span className="contact-detail">
								<small>Response time</small>
								<span>We usually reply within one business day.</span>
							</span>
						</li>
					</ul>
					<Link className="text-link" to="/enquire">Send a detailed enquiry <ArrowUpRight size={16} /></Link>
				</div>
				<div className="contact-card">
					<span className="contact-card-kicker"><Send size={14} /> Reach NxoraIT</span>
					<h3>Prefer to write?</h3>
					<p>Drop us an email and our training desk will get back to you with course details, fees and the next available batch.</p>
					<a className="button button-blue" href={mailtoHref({ email: EMAIL, subject: 'Course enquiry — NxoraIT' })}>Email {EMAIL} <ArrowUpRight size={18} /></a>
					<a className="button button-cream" href={telHref(PHONE)}>Call {PHONE} <ArrowUpRight size={18} /></a>
				</div>
			</div>
		</section>
	);
}
