export const banners = [
	{
		src: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/1b4ed352-6049-44aa-94f1-9c728241a13a.png',
		alt: 'AI-native software engineer at NxoraIT',
		href: '/courses/data-science-ai',
	},
	{
		src: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/02ac11dc-4e36-41e6-849d-c6687f7ef5d5.png',
		srcSet: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/02ac11dc-4e36-41e6-849d-c6687f7ef5d5.png?width=375 375w, https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/02ac11dc-4e36-41e6-849d-c6687f7ef5d5.png?width=768 768w, https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/02ac11dc-4e36-41e6-849d-c6687f7ef5d5.png?width=1024 1024w, https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/02ac11dc-4e36-41e6-849d-c6687f7ef5d5.png?width=1440 1440w, https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/02ac11dc-4e36-41e6-849d-c6687f7ef5d5.png 1472w',
		alt: 'Azure Data Engineering training at NxoraIT',
		href: '/courses/azure-data-engineering',
	},
	{
		src: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/02ac11dc-4e36-41e6-849d-c6687f7ef5d5.png',
		alt: 'DevOps and cloud training at NxoraIT',
		href: '/courses/cloud-devops',
	},
	{
		src: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/68535640-a3c2-401c-8b2a-bad7906f1104.png',
		alt: 'Data Analytics Online Training at NxoraIT',
		href: '/courses/data-analytics',
	},
	{
		src: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/fbbabeea-e9da-440e-b009-f5451a8e3249.png',
		alt: 'React JS Full Stack Frontend at NxoraIT',
		href: '/courses/full-stack-development',
	},
];

export const posts = [
	{
		title: 'What is a Python full-stack developer salary?',
		excerpt: 'Python full-stack developer salary is one of the most searched queries among aspiring developers planning their next career step.',
		image: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/a2e3f76e-6028-4f45-96a6-4cb396116e4b.png',
		srcSet: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/a2e3f76e-6028-4f45-96a6-4cb396116e4b.png?width=375 375w, https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/a2e3f76e-6028-4f45-96a6-4cb396116e4b.png?width=768 768w, https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/a2e3f76e-6028-4f45-96a6-4cb396116e4b.png 1344w',
		href: '/courses/python-programming',
	},
	{
		title: 'How to start learning data science?',
		excerpt: 'If you want to start learning data science, you are in the right place. Data science is one of the most practical paths into technology.',
		image: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/12358530-9a65-4e18-b08c-d976b0613817.png',
		srcSet: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/12358530-9a65-4e18-b08c-d976b0613817.png?width=375 375w, https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/12358530-9a65-4e18-b08c-d976b0613817.png?width=768 768w, https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/12358530-9a65-4e18-b08c-d976b0613817.png 1344w',
		href: '/courses/data-science-ai',
	},
	{
		title: 'What technologies are included in full stack?',
		excerpt: 'Full stack technologies include a combination of frontend, backend, and database tools used to build complete applications.',
		image: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/0e59ecf7-e864-4c6e-a586-44ad0893d21c.png',
		srcSet: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/0e59ecf7-e864-4c6e-a586-44ad0893d21c.png?width=375 375w, https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/0e59ecf7-e864-4c6e-a586-44ad0893d21c.png?width=768 768w, https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/0e59ecf7-e864-4c6e-a586-44ad0893d21c.png 1344w',
		href: '/courses/full-stack-development',
	},
	{
		title: 'How to get a job as a cloud and DevOps engineer',
		excerpt: 'Companies look for people who can deploy, monitor and improve systems. A practical project portfolio is the clearest way to show that.',
		image: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/02ac11dc-4e36-41e6-849d-c6687f7ef5d5.png',
		srcSet: 'https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/02ac11dc-4e36-41e6-849d-c6687f7ef5d5.png?width=375 375w, https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/02ac11dc-4e36-41e6-849d-c6687f7ef5d5.png?width=768 768w, https://images.hostinger.com/ef365385-0f89-4d3c-85a1-aca011eaffe3/02ac11dc-4e36-41e6-849d-c6687f7ef5d5.png 1472w',
		href: '/courses/cloud-devops',
	},
];

export const featured = [
	{ label: 'Python', tone: '#3d4db7', href: '/courses/python-programming' },
	{ label: 'DevOps', tone: '#2f6fde', href: '/courses/cloud-devops' },
	{ label: 'Data Analytics', tone: '#1aa0c8', href: '/courses/data-analytics' },
	{ label: 'Full Stack', tone: '#e4572e', href: '/courses/full-stack-development' },
	{ label: 'AI & ML', tone: '#5b4db7', href: '/courses/data-science-ai' },
	{ label: 'Azure Data', tone: '#0078d4', href: '/courses/azure-data-engineering' },
	{ label: 'Cybersecurity', tone: '#c0392b', href: '/courses/cybersecurity' },
	{ label: 'AWS', tone: '#232f3e', href: '/courses/cloud-devops' },
	{ label: 'Power BI', tone: '#f2c811', href: '/courses/data-analytics', ink: '#1c202c' },
	{ label: 'React', tone: '#149eca', href: '/courses/full-stack-development' },
	{ label: 'Docker', tone: '#0db7ed', href: '/courses/cloud-devops', ink: '#1c202c' },
];
