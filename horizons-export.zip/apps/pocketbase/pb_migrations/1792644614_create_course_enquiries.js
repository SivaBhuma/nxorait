migrate((app) => {
 let collection;
 try { collection = app.findCollectionByNameOrId('course_enquiries'); } catch (_) {
  collection = new Collection({ name: 'course_enquiries', type: 'base', listRule: null, viewRule: null, createRule: '@request.body.consent = true', updateRule: null, deleteRule: null, fields: [
   { name: 'name', type: 'text', required: true, min: 2, max: 120 },
   { name: 'email', type: 'email', required: true },
   { name: 'course', type: 'text', required: true, max: 120 },
   { name: 'message', type: 'text', max: 3000 },
   { name: 'consent', type: 'bool', required: true },
   { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
   { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true }
  ] });
  app.save(collection);
 }
}, (app) => { const collection = app.findCollectionByNameOrId('course_enquiries'); app.delete(collection); });
